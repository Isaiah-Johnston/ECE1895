#include "global.h"

#ifndef INITIALIZE_H
#define INITIALIZE_H

bool initialize();

#endif // INITIALIZE_H